for i in range(3):
    print(i) if i!=1 else next

