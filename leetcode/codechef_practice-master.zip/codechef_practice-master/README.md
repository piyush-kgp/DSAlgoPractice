# codechef_practice
This repository contains codes I wrote while practicing on Codechef
